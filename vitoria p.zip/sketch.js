// divertidamente, LIVRE-COMEDIA 
// guardioes da galaxia,12-fantasia e AÇAO
// shrek,LIVRE-COMEDIA
// o rei leao,LIVRE-COMEDIA
// o diario da tati,LIVRE-COMEDIA






function setup() {
    createCanvas(400, 400);
}

function draw() {
  background(220);
 let recomendaçao=geraRecomendaçao();
 text(recomendaçao, width / 2, height / 2);  
}
  
function geraRecomendaçao() {
  

}
  
  
  
  
  
  
  
  
  
  
  